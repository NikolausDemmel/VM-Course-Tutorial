struct s { 
  int *p; 
  int i;
}

void main(){
  struct s * pp;
  pp.i = 1+2*3+2;
}