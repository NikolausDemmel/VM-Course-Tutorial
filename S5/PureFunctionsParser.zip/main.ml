open Printf 

let parse buf : Puf.expr =
  Puf_pars.exp Puf_lex.puftok buf

let main () =
  let lexbuf = Lexing.from_channel stdin in
  printf "%s\n" (Puf.exprToString (parse lexbuf))

let _ = Printexc.print main () 
