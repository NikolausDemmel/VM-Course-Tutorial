PuF:			*.f
MaMa Call By Value:	*.f.cbv 
MaMa Call By Need:	*.f.cbn
