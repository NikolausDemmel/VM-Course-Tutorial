type unop = Neg

type binop = Add | Sub | Mul | Div | Leq | Le | Geq | Gr | Eq | Neq

type expr = 
  | Var of string
  | Val of int
  | Unop of unop * expr
  | Binop of expr * binop * expr
  | IfThenElse of expr * expr * expr
  | App of expr * (expr list)
  | Fun of string list * expr
  | Let of string * expr * expr
  | LetRec of (string * expr) list * expr 

(* helper functions *)

let binopToString = function
  | Add -> "+" 
  | Sub -> "-"
  | Mul -> "*"
  | Div -> "/"
  | Leq -> "<="
  | Le  -> "<"
  | Geq -> ">="
  | Gr  -> ">"
  | Eq  -> "=="
  | Neq -> "!="

let rec concatApp = function
  | [] -> failwith "BROKEN" 
  | [x] -> x
  | x::xs -> x^" "^concatApp xs

let rec letRecToString = function
  | [] -> failwith "BROKEN"
  | [x,y] -> x^" = "^exprToString y
  | (x,y)::xs -> x^" = "^exprToString y^" and "^letRecToString xs

and exprToString = function
  | Var x              -> x
  | Val x              -> string_of_int x 
  | Unop (Neg,x)       -> "(~"^exprToString x^")"
  | Binop (x,op,y)     -> "("^exprToString x^binopToString op^exprToString y^")"
  | IfThenElse (b,x,y) -> "(if "^exprToString b^" then "^exprToString x^" else "^exprToString y^")"
  | App (f,xs)         -> "("^exprToString f^" "^concatApp (List.map exprToString xs)^")"
  | Fun (xs,e)         -> "(fun "^concatApp xs^" -> "^exprToString e^")"
  | Let (x,e1,e2)      -> "(let "^x^" = "^exprToString e1^" in "^exprToString e2^")"
  | LetRec (ds,e)      -> "(let rec "^letRecToString ds^" in "^exprToString e^")"