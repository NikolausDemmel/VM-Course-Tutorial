The ocamllex/yacc parser for PuF (Pure Functions) language.

(currently it only echoes valid expressions back to the user)

1) build with 
  ocamlbuild main.native

2) edit main.ml so that it does something interesting

3) ...

4) profit