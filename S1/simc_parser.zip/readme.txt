Biggest simplifications:
 * only int constants, fewer operators
 * no casts, no typedef
 * no function pointer type --- difficult to parse, also we don't care
 * identifiers prohibit more special symbols (like '_')
 * no semicolon after "struct n {...}"
